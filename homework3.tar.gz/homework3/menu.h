/**************************************************************************************************/
/* Copyright SSE@USTC, 2014-2015                                                                  */
/*                                                                                                */
/*  FILE NAME             :  menu.h                                                               */
/*  PRINCIPAL AUTHOR      :  Hangchongyang                                                        */
/*  SUBSYSTEM NAME        :  menu                                                                 */
/*  MODULE NAME           :  menu                                                                 */
/*  LANGUAGE              :  C                                                                    */
/*  TARGET ENVIRONMENT    :  ANY                                                                  */
/*  DATE OF FIRST RELEASE :  2014/09/23                                                           */
/*  DESCRIPTION           :  menu.h of menu.c                                                     */
/**************************************************************************************************/

/* DataNode defination */

typedef struct DataNode
{
	tLinkTableNode * pNext;
    char*   cmd;
    char*   desc;
    struct  DataNode *next;
} tDataNode;

/* Data Defination */

#define DESC_LEN    1024
#define CMD_NUM     10

/* InitLinkTable Function */

tLinkTable * InitLinkTable(tLinkTable * head,tDataNode data[2]);

/* FindCmd Function */

tDataNode* FindCmd(tLinkTable * head, char * cmd);

/* ShowAllCmd Function */

int ShowAllCmd(tLinkTable * head);

/* AddCmd Function */

int AddCmd(tLinkTable *p,tLinkTableNode *pNode);

/* DeleteCmd Function */

int DeleteCmd(tLinkTable * p,tDataNode * pNode);
