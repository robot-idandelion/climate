/**************************************************************************************************/
/* Copyright SSE@USTC, 2014-2015                                                                  */
/*                                                                                                */
/*  FILE NAME             :  test.c                                                               */
/*  PRINCIPAL AUTHOR      :  Hangchongyang                                                        */
/*  SUBSYSTEM NAME        :  test                                                                 */
/*  MODULE NAME           :  test                                                                 */
/*  LANGUAGE              :  C                                                                    */
/*  TARGET ENVIRONMENT    :  ANY                                                                  */
/*  DATE OF FIRST RELEASE :  2014/09/29                                                           */
/*  DESCRIPTION           :  this is program test.c                                               */
/**************************************************************************************************/

#include<stdio.h>
#include"linktable.h"
#include"menu.h"

#define debug printf

int results[5] = {1,1,1,1,1};
int resultsInput[5] = {1,1,1,1,1};
char * info[5] =
{
    "InitLinkTable fail",
    "AddCmd fail",
    "FindCmd fail",
    "ShowAllCmd fail",
    "DeleteCmd fail"
};
char * infoInput[5] =
{
	"InitLinkTable without input",
	"AddCmd without input",
	"FindCmd without input",
	"ShowAllCmd without input",
	"DeleteCmd without input"
};

int main()
{
    {
		int i;
		tLinkTable * head;
		tDataNode * data = NULL;
		tLinkTable *p = InitLinkTable(head,data);
		if(p == NULL)
		{
			debug("init fail\n");
			results[0] = 1;
		}
		if(head == NULL || data == NULL)
		{
			debug("InitLinkTable no input\n");
			resultsInput[0] = 1;
		}
	}

	/* InitLinkTable test */

    {
		tLinkTableNode * pNode;
		tLinkTable * p;
		int ret = AddCmd(p,pNode);
		if(ret == 1)
		{
			debug("AddCmd fail\n");
			results[1] = 1;
		}
		if(p == NULL || pNode == NULL)
		{
			debug("AddCmd no input\n");
			resultsInput[1] = 1;
		}
	}

	/* AddCmd test */

	{
		tLinkTable * FindCmdP;
		char * FindCmdCmd;
		tDataNode * node = FindCmd(FindCmdP,FindCmdCmd);
		if(node == NULL)
		{
			debug("FindCmd fail\n");
			results[2] = 1;
		}
		if(FindCmdCmd == NULL || FindCmdP == NULL)
		{
			debug("FindCmd no input\n");
			resultsInput[2] = 1;
		}
	}

	/* AddCmd test */

	{
		tLinkTable * ShowAllCmdP = NULL;
		int ShowAllCmdInt = ShowAllCmd(ShowAllCmdP);
		if(ShowAllCmdInt == 0)
		{
			debug("ShowAllCmd fail\n");
			results[3] = 1;
		}
		if(ShowAllCmdP == NULL)
		{
			debug("ShowAllCmd no input\n");
			resultsInput[3] = 1;
		}
	}

	/* ShowAllCmdP test */

	{
		tLinkTable * P;
		tDataNode * cmd;
		int deleteInt = DeleteCmd(P,cmd);
		if(deleteInt == 0)
		{
			debug("DeleteCmd fail\n");
			results[4] = 0;
		}
		if(P == NULL || cmd == NULL)
		{
			debug("DeleteCmd no input\n");
			resultsInput[4] = 1;
		}
	}

	/* DeleteCmd test */

    /* test report */
    printf("test report\n");
    int i;
    for(i=0;i<=3;i++)
    {
        if(results[i] == 1)
        {
            printf("Testcase Number%d F - %s\n",i,info[i]);
        }
    }
	for(i=0;i<=3;i++)
	{
		if(resultsInput[i] == 1)
		{
			printf("Testcase Number%d F - %s\n",i,infoInput[i]);
		}
	}
}
