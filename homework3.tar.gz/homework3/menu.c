/**************************************************************************************************/
/* Copyright SSE@USTC, 2014-2015                                                                  */
/*                                                                                                */
/*  FILE NAME             :  menu.c                                                               */
/*  PRINCIPAL AUTHOR      :  Hangchongyang                                                        */
/*  SUBSYSTEM NAME        :  menu                                                                 */
/*  MODULE NAME           :  menu                                                                 */
/*  LANGUAGE              :  C                                                                    */
/*  TARGET ENVIRONMENT    :  ANY                                                                  */
/*  DATE OF FIRST RELEASE :  2014/09/22                                                           */
/*  DESCRIPTION           :  This is a menu program                                               */
/**************************************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include "linktable.h"
#include "menu.h"

#define DESC_LEN    1024
#define CMD_NUM     10

/* function  FindCmd */

tDataNode* FindCmd(tLinkTable * head, char * Cmd)
{
	return NULL;
}

/* function ShowAllCmd */

int ShowAllCmd(tLinkTable * head)
{
	if(head == NULL)
	{
		return 0;
	}
	printf("cmd list:\n");
	tDataNode * pNode = (tDataNode*)GetLinkTableHead(head);
	while(pNode != NULL)
	{
        	printf("%s - %s\n", pNode->cmd, pNode->desc);
        	pNode = (tDataNode*)GetNextLinkTableNode(head,(tLinkTableNode *)pNode);
    	}
	return 1;
}

/* Init a linktable */

tLinkTable* InitLinkTable(tLinkTable * head,tDataNode *data)
{
	head = CreateLinkTable();
	AddLinkTableNode(head,(tLinkTableNode *)data);
	return head;
}

int AddCmd(tLinkTable *p,tLinkTableNode *pNode)
{
		return 0;
}

int DeleteCmd(tLinkTable * p,tDataNode * pNode)
{
		return 0;
}
